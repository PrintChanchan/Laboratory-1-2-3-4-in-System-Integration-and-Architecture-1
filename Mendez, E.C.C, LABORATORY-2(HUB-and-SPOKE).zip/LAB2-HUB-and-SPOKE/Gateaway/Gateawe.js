    const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

const SERVICES = {
    users: 'http://localhost:5001/users',
    products: 'http://localhost:5002/products',
    orders: 'http://localhost:5003/orders'
};

app.get('/api/dashboard', async (req, res) => {
    try {
        const [users, products, orders] = await Promise.all([
            axios.get(SERVICES.users),
            axios.get(SERVICES.products),
            axios.get(SERVICES.orders)
        ]);

        res.json({
            gateway: 'API Gateway',
            status: 'success',
            timestamp: new Date().toISOString(),

            summary: {
                totalUsers: users.data.count,
                totalProducts: products.data.count,
                totalOrders: orders.data.count
            },

            data: {
                users: users.data.data,
                products: products.data.data,
                orders: orders.data.data
            }
        });

    } catch (error) {
        res.status(500).json({
            gateway: 'API Gateway',
            status: 'error',
            error: 'Failed to fetch data from one or more services',
            details: error.message
        });
    }
});

app.get('/api/status', async (req, res) => {
    try {
        const [users, products, orders] = await Promise.all([
            axios.get('http://localhost:5001/ping'),
            axios.get('http://localhost:5002/ping'),
            axios.get('http://localhost:5003/ping')
        ]);

        res.json({
            gateway: 'online',
            allOnline: true,
            services: {
                users: users.data,
                products: products.data,
                orders: orders.data
            }
        });

    } catch (error) {
        res.status(500).json({
            gateway: 'online',
            allOnline: false,
            error: error.message
        });
    }
});

// Get Users
app.get('/api/users', async (req, res) => {
    try {
        const response = await axios.get(SERVICES.users);
        res.json(response.data);
    } catch (error) {
        res.status(500).json({
            error: 'User Service unavailable'
        });
    }
});

app.get('/api/products', async (req, res) => {
    try {
        const response = await axios.get(SERVICES.products);
        res.json(response.data);
    } catch (error) {
        res.status(500).json({
            error: 'Product Service unavailable'
        });
    }
});

// Get Orders
app.get('/api/orders', async (req, res) => {
    try {
        const response = await axios.get(SERVICES.orders);
        res.json(response.data);
    } catch (error) {
        res.status(500).json({
            error: 'Order Service unavailable'
        });
    }
});

app.listen(PORT, () => {
    console.log('========================================');
    console.log('API GATEWAY STARTED');
    console.log('========================================');
    console.log(`Port: ${PORT}`);
    console.log('GET /api/dashboard');
    console.log('GET /api/status');
    console.log('GET /api/users');
    console.log('GET /api/products');
    console.log('GET /api/orders');
    console.log('========================================');
});