const express = require('express');
const app = express();

const PORT = 5001;

const users = [
    { id: 1, name: 'Sunshine marie De la', email: 'Cruz?@email.com', role: 'tounge' },
    { id: 2, name: 'Nathaniel Borbon', email: 'Birimafiaboss@email.com', role: 'Racer' },
    { id: 3, name: 'Jamprix Siervo', email: 'TakatakPambujan@email.com', role: 'Editor' },
    { id: 4, name: 'Jamelskie Lozano', email: 'UPAODancer@email.com', role: 'Dancer' },
    { id: 5, name: 'Aldrits EsPinya', email: 'Adlet@email.com', role: 'Boss' }
];

app.get('/users', (req, res) => {
    console.log('User Service: Returning', users.length, 'users');

    res.json({
        service: 'User Service',
        status: 'success',
        count: users.length,
        data: users,
        timestamp: new Date().toISOString()
    });
});

app.get('/ping', (req, res) => {
    res.json({
        status: 'online',
        service: 'User Service'
    });
});

app.listen(PORT, () => {
    console.log('========================================');
    console.log('USER SERVICE STARTED');
    console.log('========================================');
    console.log(`Port: ${PORT}`);
    console.log(`GET /users - Returns ${users.length} users`);
    console.log('GET /ping - Health check');
    console.log('========================================');
});