
const bcrypt = require('bcrypt');
const express = require('express');
const path = require('path');

const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// In-memory database
let users = [];
let nextId = 1;

// Helper functions
const findUserById = (id) => users.find((u) => u.id === id);

const findUserByEmail = (email) =>
  users.find(
    (u) => u.email.toLowerCase() === String(email).trim().toLowerCase()
  );

const sanitizeUser = (user) => {
  const { password, ...safe } = user;
  return safe;
};

// GET all users
app.get('/api/users', (req, res) => {
  res.json(users.map(sanitizeUser));
});

// CREATE user — hash password using bcrypt
app.post('/api/users', async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        error: 'Name, email, and password are required.'
      });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(email)) {
      return res.status(400).json({
        error: 'Invalid email format.'
      });
    }

    if (findUserByEmail(email)) {
      return res.status(409).json({
        error: 'Email already registered.'
      });
    }

    let normalizedRole = 'user';

    if (role === 'admin') normalizedRole = 'admin';
    else if (role === 'staff') normalizedRole = 'staff';

    const hashed = await bcrypt.hash(password, 10);

    const newUser = {
      id: nextId++,
      name,
      email: email.trim(),
      password: hashed,
      role: normalizedRole
    };

    users.push(newUser);

    return res.status(201).json(sanitizeUser(newUser));
  } catch (error) {
    console.error('Create user error:', error);
    return res.status(500).json({ error: 'Internal server error.' });
  }
});

// GET one user
app.get('/api/users/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);

  if (isNaN(id)) {
    return res.status(400).json({ error: 'Invalid user ID.' });
  }

  const user = findUserById(id);

  if (!user) {
    return res.status(404).json({ error: 'User not found.' });
  }

  return res.json(sanitizeUser(user));
});

// UPDATE user — hash password if a new password is supplied
app.put('/api/users/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const { name, email, password, role } = req.body;

    if (isNaN(id)) {
      return res.status(400).json({ error: 'Invalid user ID.' });
    }

    if (!name || !email) {
      return res.status(400).json({
        error: 'Name and email are required.'
      });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(email)) {
      return res.status(400).json({
        error: 'Invalid email format.'
      });
    }

    const user = findUserById(id);

    if (!user) {
      return res.status(404).json({ error: 'User not found.' });
    }

    const existing = findUserByEmail(email);

    if (existing && existing.id !== id) {
      return res.status(409).json({
        error: 'Email already registered.'
      });
    }

    user.name = name;
    user.email = email.trim();

    if (password) {
      user.password = await bcrypt.hash(password, 10);
    }

    if (role === 'admin' || role === 'staff' || role === 'user') {
      user.role = role;
    }

    return res.json(sanitizeUser(user));
  } catch (error) {
    console.error('Update user error:', error);
    return res.status(500).json({ error: 'Internal server error.' });
  }
});

// DELETE user
app.delete('/api/users/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);

  if (isNaN(id)) {
    return res.status(400).json({ error: 'Invalid user ID.' });
  }

  const index = users.findIndex((u) => u.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'User not found.' });
  }

  users.splice(index, 1);

  return res.status(204).send();
});

// LOGIN — compare submitted password with bcrypt hash
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        error: 'Email and password are required.'
      });
    }

    const user = findUserByEmail(email);

    if (!user) {
      return res.status(401).json({
        error: 'Invalid email or password.'
      });
    }

    const match = await bcrypt.compare(password, user.password);

    if (!match) {
      return res.status(401).json({
        error: 'Invalid email or password.'
      });
    }

    let redirectTo = '/user.html';

    if (user.role === 'admin') redirectTo = '/admin.html';
    else if (user.role === 'staff') redirectTo = '/staff.html';

    return res.json({
      message: 'Login successful',
      user: sanitizeUser(user),
      redirectTo
    });
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ error: 'Internal server error.' });
  }
});

// Start server
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`Login page: http://localhost:${PORT}/login.html`);
});
