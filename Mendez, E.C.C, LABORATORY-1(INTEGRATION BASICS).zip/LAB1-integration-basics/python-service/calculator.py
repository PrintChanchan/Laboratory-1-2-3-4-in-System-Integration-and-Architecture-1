from flask import Flask, request, jsonify
import math

app = Flask(__name__)


@app.route('/calculate', methods=['POST'])
def calculate():

    data = request.get_json()

    num1 = data.get('num1', 0)
    num2 = data.get('num2', 0)
    operation = data.get('operation', 'add')

    if operation == 'add':
        result = num1 + num2

    elif operation == 'subtract':
        result = num1 - num2

    elif operation == 'multiply':
        result = num1 * num2

    elif operation == 'divide':
        result = num1 / num2 if num2 != 0 else "Error: Division by zero"

    elif operation == 'modulo':
        result = num1 % num2

    elif operation == 'power':
        result = num1 ** num2

    elif operation == 'square_root':
        result = math.sqrt(num1)

    else:
        result = "Invalid operation"

    return jsonify({
        'status': 'Nayswan',
        'input': data,
        'result': result,
        'message': 'Calculation passed!'
    })


@app.route('/ping', methods=['GET'])
def ping():

    return jsonify({
        'status': 'Python is jogging!'
    })


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)
