
require('dotenv').config();

const express = require('express');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const mysql = require('mysql2/promise');
const redis = require('redis');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10
});

const redisPublisher = redis.createClient({
    url: process.env.REDIS_URL
});

const redisSubscriber = redis.createClient({
    url: process.env.REDIS_URL
});

redisPublisher.on('error', (err) => {
    console.error('Redis Publisher Error:', err);
});

redisSubscriber.on('error', (err) => {
    console.error('Redis Subscriber Error:', err);
});

async function connectRedis() {
    try {
        await redisPublisher.connect();
        await redisSubscriber.connect();

        console.log('Connected to Redis Message Broker');

        // Listen for admin announcements
        await redisSubscriber.subscribe('admin_broadcast', (message) => {
            io.emit('new_announcement', JSON.parse(message));
        });

        // Listen for user login events
        await redisSubscriber.subscribe('user_login_events', (message) => {
            io.emit('user_logged_in', JSON.parse(message));
        });

    } catch (err) {
        console.error('Redis connection error:', err);
    }
}

connectRedis();

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({
            error: 'Access Denied: No Token Provided'
        });
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({
                error: 'Invalid Token'
            });
        }

        req.user = user;
        next();
    });
};

const isAdmin = (req, res, next) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({
            error: 'Admin privileges required'
        });
    }

    next();
};

// USER REGISTRATION
app.post('/api/register', async (req, res) => {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
        return res.status(400).json({
            error: 'All fields are required'
        });
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);

        // Public registration always creates a normal user
        await pool.execute(
            'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
            [name, email, hashedPassword, 'user']
        );

        res.status(201).json({
            message: 'Registration successful'
        });

    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({
                error: 'Email already exists'
            });
        }

        console.error(err);

        res.status(500).json({
            error: 'Internal server error'
        });
    }
});

app.post('/api/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        const [rows] = await pool.execute(
            'SELECT * FROM users WHERE email = ?',
            [email]
        );

        const user = rows[0];

        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({
                error: 'Invalid email or password'
            });
        }

        const token = jwt.sign(
            {
                id: user.id,
                role: user.role,
                name: user.name
            },
            process.env.JWT_SECRET,
            { expiresIn: '1h' }
        );

        await pool.execute(
            'INSERT INTO login_logs (user_id) VALUES (?)',
            [user.id]
        );

        // Publish login event through Redis
        await redisPublisher.publish(
            'user_login_events',
            JSON.stringify({
                name: user.name,
                role: user.role,
                time: new Date().toLocaleTimeString()
            })
        );

        res.json({
            token,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                role: user.role
            },
            redirectTo: `/${user.role}.html`
        });

    } catch (err) {
        console.error(err);

        res.status(500).json({
            error: 'Server error'
        });
    }
});


app.put('/api/profile', authenticateToken, async (req, res) => {
    const { name, email, currentPassword, newPassword } = req.body;

    try {
        const [rows] = await pool.execute(
            'SELECT * FROM users WHERE id = ?',
            [req.user.id]
        );

        const user = rows[0];

        if (!user) {
            return res.status(404).json({
                error: 'User not found'
            });
        }

        let updateQuery =
            'UPDATE users SET name = ?, email = ? WHERE id = ?';

        let params = [name, email, req.user.id];

        if (newPassword) {
            if (!currentPassword) {
                return res.status(400).json({
                    error: 'Current password required'
                });
            }

            const match = await bcrypt.compare(
                currentPassword,
                user.password
            );

            if (!match) {
                return res.status(401).json({
                    error: 'Current password is incorrect'
                });
            }

            const hashedNew = await bcrypt.hash(newPassword, 10);

            updateQuery =
                'UPDATE users SET name = ?, email = ?, password = ? WHERE id = ?';

            params = [name, email, hashedNew, req.user.id];
        }

        await pool.execute(updateQuery, params);

        res.json({
            message: 'Profile updated',
            name,
            email
        });

    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({
                error: 'Email already in use'
            });
        }

        console.error(err);

        res.status(500).json({
            error: 'Internal server error'
        });
    }
});


// GET ALL USERS
app.get('/api/users', authenticateToken, isAdmin, async (req, res) => {
    try {
        const [rows] = await pool.execute(
            'SELECT id, name, email, role FROM users'
        );

        res.json(rows);

    } catch (err) {
        console.error(err);

        res.status(500).json({
            error: 'Failed to retrieve users'
        });
    }
});

// UPDATE USER
app.put('/api/users/:id', authenticateToken, isAdmin, async (req, res) => {
    const { name, email, role } = req.body;

    try {
        await pool.execute(
            'UPDATE users SET name = ?, email = ?, role = ? WHERE id = ?',
            [name, email, role, req.params.id]
        );

        res.json({
            message: 'User updated'
        });

    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({
                error: 'Email might already exist'
            });
        }

        console.error(err);

        res.status(500).json({
            error: 'Update failed'
        });
    }
});

// DELETE USER
app.delete('/api/users/:id', authenticateToken, isAdmin, async (req, res) => {
    if (Number(req.params.id) === Number(req.user.id)) {
        return res.status(403).json({
            error: 'You cannot delete your own admin account'
        });
    }

    try {
        await pool.execute(
            'DELETE FROM users WHERE id = ?',
            [req.params.id]
        );

        res.status(204).send();

    } catch (err) {
        console.error(err);

        res.status(500).json({
            error: 'Delete failed'
        });
    }
});


app.post('/api/broadcast', authenticateToken, isAdmin, async (req, res) => {
    const { message } = req.body;

    if (!message) {
        return res.status(400).json({
            error: 'Announcement message is required'
        });
    }

    try {
        const [result] = await pool.execute(
            'INSERT INTO announcements (message) VALUES (?)',
            [message]
        );

        const [rows] = await pool.execute(
            'SELECT * FROM announcements WHERE id = ?',
            [result.insertId]
        );

        // Publish announcement through Redis
        await redisPublisher.publish(
            'admin_broadcast',
            JSON.stringify(rows[0])
        );

        res.status(201).json(rows[0]);

    } catch (err) {
        console.error(err);

        res.status(500).json({
            error: 'Broadcast failed'
        });
    }
});


io.on('connection', (socket) => {
    console.log('A client connected:', socket.id);
});


server.listen(process.env.PORT || 3000, () => {
    console.log(`Server running on port ${process.env.PORT || 3000}`);
});
